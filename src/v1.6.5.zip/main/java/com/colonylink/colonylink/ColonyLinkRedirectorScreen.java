package com.colonylink.colonylink;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class ColonyLinkRedirectorScreen extends AbstractContainerScreen<ColonyLinkRedirectorMenu>
{
    private static final int GUI_WIDTH = 230;
    private static final int GUI_HEIGHT = 204;

    public ColonyLinkRedirectorScreen(ColonyLinkRedirectorMenu menu, Inventory playerInventory, Component title)
    {
        super(menu, playerInventory, title);
        this.imageWidth = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
    }

    @Override
    protected void init()
    {
        super.init();
        this.titleLabelX = 8;
        this.titleLabelY = 6;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = 113;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY)
    {
        int x = this.leftPos;
        int y = this.topPos;

        // Fond principal
        graphics.fill(x, y, x + imageWidth, y + imageHeight, 0xFF8B8B8B);
        graphics.fill(x, y, x + imageWidth, y + 2, 0xFFFFFFFF);
        graphics.fill(x, y, x + 2, y + imageHeight, 0xFFFFFFFF);
        graphics.fill(x, y + imageHeight - 2, x + imageWidth, y + imageHeight, 0xFF111111);
        graphics.fill(x + imageWidth - 2, y, x + imageWidth, y + imageHeight, 0xFF111111);

        // Barre de titre — 36px : ligne 1 = titre, ligne 2 = wand status + slot card
        graphics.fill(x + 2, y + 2, x + imageWidth - 2, y + 48, 0xFF6B6B6B);
        graphics.fill(x + 2, y + 2, x + imageWidth - 2, y + 4, 0xFF8B8B8B);

        // Infos redirector
        ColonyLinkRedirectorBlockEntity be = menu.getBlockEntity();
        if (be != null)
        {
            // Statut wand — gauche ligne 2
            boolean wandLinked = false;
            if (Minecraft.getInstance().player != null)
            {
                for (ItemStack stack : Minecraft.getInstance().player.getInventory().items)
                {
                    if (stack.getItem() instanceof ColonyLinkWand)
                    {
                        wandLinked = ColonyLinkWandLinkableHandler.isLinked(stack);
                        break;
                    }
                }
            }
            // Nom du builder lié
            String bName = (be.getLinkedBuilderPos() != null)
                    ? be.getLinkedBuilderName() : "";
            if (!bName.isEmpty() && !bName.equals("N/A"))
                graphics.drawString(this.font, Component.translatable("colonylink.screen.info.builder", bName).getString(), x + 8, y + 18, 0xFFFFFF, false);

            String wandText = (wandLinked ? Component.translatable("colonylink.redir.clipboard_linked").getString() : Component.translatable("colonylink.redir.clipboard_unlinked").getString());
            int wandColor = wandLinked ? 0x00FF00 : 0xFF4444;
            graphics.drawString(this.font, wandText, x + 8, y + 34, wandColor, false);
        }

        // ── Slot Warehouse Link Card — dans la barre de titre, x=170 y=10 ──────
        int cardSlotX = x + 170;
        int cardSlotY = y + 20;

        // Fond du slot : légèrement doré pour le distinguer du buffer
        graphics.fill(cardSlotX - 1, cardSlotY - 1, cardSlotX + 17, cardSlotY + 17, 0xFF665500);
        graphics.fill(cardSlotX, cardSlotY, cardSlotX + 16, cardSlotY + 16, 0xFF4A3A00);
        graphics.fill(cardSlotX, cardSlotY, cardSlotX + 16, cardSlotY + 1, 0xFF332800);
        graphics.fill(cardSlotX, cardSlotY, cardSlotX + 1, cardSlotY + 16, 0xFF332800);
        graphics.fill(cardSlotX, cardSlotY + 15, cardSlotX + 16, cardSlotY + 16, 0xFF998822);
        graphics.fill(cardSlotX + 15, cardSlotY, cardSlotX + 16, cardSlotY + 16, 0xFF998822);

        // Statut warehouse card : affiché SOUS le slot (y+24) pour éviter tout chevauchement
        boolean hasCard = be != null && be.hasWarehouseCard();
        int cardTextColor = hasCard ? 0x00FF88 : 0x666666;
        graphics.drawString(this.font, hasCard ? "W✔" : "W?", cardSlotX + 20, cardSlotY + 4, cardTextColor);

        // Zone buffer — commence à y+40 (après la barre de titre élargie)
        graphics.fill(x + 6, y + 50, x + imageWidth - 6, y + 109, 0xFF373737);
        graphics.fill(x + 6, y + 50, x + imageWidth - 6, y + 51, 0xFF8B8B8B);
        graphics.fill(x + 6, y + 50, x + 7, y + 109, 0xFF8B8B8B);

        // Slots buffer
        int bufferCols = ColonyLinkRedirectorBlockEntity.BUFFER_COLS;
        int bufferRows = ColonyLinkRedirectorBlockEntity.BUFFER_ROWS;
        for (int row = 0; row < bufferRows; row++)
        {
            for (int col = 0; col < bufferCols; col++)
            {
                int slotX = x + 8 + col * 18;
                int slotY = y + 52 + row * 18;
                graphics.fill(slotX, slotY, slotX + 16, slotY + 16, 0xFF4A4A4A);
                graphics.fill(slotX, slotY, slotX + 16, slotY + 1, 0xFF373737);
                graphics.fill(slotX, slotY, slotX + 1, slotY + 16, 0xFF373737);
                graphics.fill(slotX, slotY + 15, slotX + 16, slotY + 16, 0xFF8B8B8B);
                graphics.fill(slotX + 15, slotY, slotX + 16, slotY + 16, 0xFF8B8B8B);
            }
        }

        // Séparateur
        graphics.fill(x + 6, y + 110, x + imageWidth - 6, y + 111, 0xFF555555);

        // Zone inventaire joueur
        graphics.fill(x + 6, y + 112, x + imageWidth - 6, y + 202, 0xFF373737);
        graphics.fill(x + 6, y + 179, x + imageWidth - 6, y + 180, 0xFF555555);

        // Slots inventaire joueur
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 9; col++)
            {
                int slotX = x + 8 + col * 18;
                int slotY = y + 123 + row * 18;
                graphics.fill(slotX, slotY, slotX + 16, slotY + 16, 0xFF4A4A4A);
                graphics.fill(slotX, slotY, slotX + 16, slotY + 1, 0xFF373737);
                graphics.fill(slotX, slotY, slotX + 1, slotY + 16, 0xFF373737);
                graphics.fill(slotX, slotY + 15, slotX + 16, slotY + 16, 0xFF8B8B8B);
                graphics.fill(slotX + 15, slotY, slotX + 16, slotY + 16, 0xFF8B8B8B);
            }
        }

        // Slots hotbar
        for (int col = 0; col < 9; col++)
        {
            int slotX = x + 8 + col * 18;
            int slotY = y + 181;
            graphics.fill(slotX, slotY, slotX + 16, slotY + 16, 0xFF4A4A4A);
            graphics.fill(slotX, slotY, slotX + 16, slotY + 1, 0xFF373737);
            graphics.fill(slotX, slotY, slotX + 1, slotY + 16, 0xFF373737);
            graphics.fill(slotX, slotY + 15, slotX + 16, slotY + 16, 0xFF8B8B8B);
            graphics.fill(slotX + 15, slotY, slotX + 16, slotY + 16, 0xFF8B8B8B);
        }
    }

    /**
     * Override renderSlot — même comportement que les terminaux AE2 :
     * si le slot contient un DomumPatternItem, rend l'item cible à la place.
     * On reproduit manuellement le rendu vanilla du slot (fond + item + décos)
     * en substituant l'item.
     */
    @Override
    protected void renderSlot(GuiGraphics graphics, net.minecraft.world.inventory.Slot slot)
    {
        net.minecraft.world.item.ItemStack inSlot = slot.getItem();
        // Vue "bloc cible" UNIQUEMENT pour les slots propres au Redirector
        // (buffer + card = SlotItemHandler), jamais pour l'inventaire/hotbar du
        // joueur (Slot vanilla). renderSlot() étant appelé pour TOUS les slots du
        // menu, sans ce filtre les patterns restés dans l'inventaire passaient
        // aussi en vue bloc dès l'ouverture du GUI.
        if (slot instanceof net.neoforged.neoforge.items.SlotItemHandler
                && !inSlot.isEmpty() && inSlot.getItem() instanceof DomumPatternItem)
        {
            net.minecraft.world.item.ItemStack target =
                    DomumPatternItem.getTargetStackClient(inSlot);
            if (target != null && !target.isEmpty())
            {
                // Rendu du fond/highlight du slot via super (sans item)
                // On crée temporairement un slot "vide" fictif pour le fond
                // puis on rend l'item cible manuellement
                int x = slot.x;
                int y = slot.y;

                // Highlight si slot sélectionné
                if (this.isHovering(slot.x, slot.y, 16, 16, (double) lastMouseX, (double) lastMouseY))
                    graphics.fill(x, y, x + 16, y + 16, 0x80FFFFFF);

                // Rend l'item cible
                graphics.renderItem(target, x, y);
                graphics.renderItemDecorations(this.font, target, x, y, null);
                return;
            }
        }
        super.renderSlot(graphics, slot);
    }

    // Track mouse pos pour le highlight dans renderSlot
    private int lastMouseX = 0, lastMouseY = 0;

    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick)
    {
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        super.render(graphics, mouseX, mouseY, partialTick);

        // Tooltip custom pour les slots DomumPattern du buffer
        // On intercepte avant renderTooltip vanilla pour afficher les infos du pattern
        boolean domumTooltipShown = false;
        for (net.minecraft.world.inventory.Slot slot : menu.slots)
        {
            // Vérifie si la souris survole ce slot
            if (mouseX < this.leftPos + slot.x || mouseX > this.leftPos + slot.x + 16) continue;
            if (mouseY < this.topPos  + slot.y || mouseY > this.topPos  + slot.y + 16) continue;

            // Cherche l'item réel du slot (avant swap)
            // Les slots buffer sont de type SlotItemHandler
            net.minecraft.world.item.ItemStack realStack = slot.getItem();
            // Tooltip "Domum Pattern" du Redirector réservé aux slots du buffer/card
            // (SlotItemHandler) — un pattern resté dans l'inventaire garde son tooltip
            // d'item normal, cohérent avec son rendu en vue pattern.
            if (!(slot instanceof net.neoforged.neoforge.items.SlotItemHandler)) continue;
            if (!(realStack.getItem() instanceof DomumPatternItem)) continue;

            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.level == null) continue;

            net.minecraft.world.item.ItemStack target =
                    DomumPatternItem.getTargetStackClient(realStack);

            int outCount = DomumPatternItem.getOutputCount(realStack);
            java.util.List<net.minecraft.network.chat.Component> tt = new java.util.ArrayList<>();
            tt.add(net.minecraft.network.chat.Component.translatable("colonylink.redir.domum_pattern"));
            tt.add(net.minecraft.network.chat.Component.translatable("colonylink.redir.crafts")
                    .append(target.getDisplayName())
                    .append(net.minecraft.network.chat.Component.literal(
                            outCount > 1 ? " §7(×" + outCount + ")" : "")));

            // Variant — depuis l'ItemStack TARGET (le pattern encode l'item cible avec son blockstate)
            net.minecraft.world.item.component.BlockItemStateProperties bs =
                    target.get(net.minecraft.core.component.DataComponents.BLOCK_STATE);
            if (bs != null && !bs.properties().isEmpty())
            {
                for (var entry : bs.properties().entrySet())
                    tt.add(net.minecraft.network.chat.Component.literal(
                            "§7" + entry.getKey() + ": §f" + entry.getValue()));
            }
            else
            {
                tt.add(net.minecraft.network.chat.Component.translatable("colonylink.redir.no_variant"));
            }

            if (hasShiftDown())
            {
                // Matériaux — shift only
                java.util.List<DomumPatternItem.MaterialEntry> mats =
                        DomumPatternItem.getMaterials(realStack, mc.level.registryAccess());
                if (!mats.isEmpty())
                {
                    tt.add(net.minecraft.network.chat.Component.translatable("colonylink.redir.materials"));
                    for (var mat : mats)
                        if (mat.resolved())
                            tt.add(net.minecraft.network.chat.Component.literal("§7  • §f")
                                    .append(new net.minecraft.world.item.ItemStack(mat.block())
                                            .getDisplayName())
                                    .append(net.minecraft.network.chat.Component.literal(" ×1")));
                }
            }
            else
            {
                tt.add(net.minecraft.network.chat.Component.translatable("colonylink.redir.hold_shift_materials")
                        .withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
            }

            graphics.renderComponentTooltip(this.font, tt, mouseX, mouseY);
            domumTooltipShown = true;
            break;
        }

        // Tooltip du slot Warehouse Link Card
        int cardSlotX = this.leftPos + 170;
        int cardSlotY = this.topPos + 20;
        boolean cardTooltipShown = false;
        if (mouseX >= cardSlotX && mouseX <= cardSlotX + 16
                && mouseY >= cardSlotY && mouseY <= cardSlotY + 16)
        {
            List<Component> tooltip = new ArrayList<>();
            tooltip.add(Component.translatable("colonylink.redir.card_slot"));
            tooltip.add(Component.translatable("colonylink.redir.card_insert1"));
            tooltip.add(Component.translatable("colonylink.redir.card_insert2"));
            boolean hasCard = menu.getBlockEntity() != null && menu.getBlockEntity().hasWarehouseCard();
            if (hasCard)
                tooltip.add(Component.translatable("colonylink.redir.card_inserted"));
            else
                tooltip.add(Component.translatable("colonylink.redir.card_empty"));
            graphics.renderComponentTooltip(this.font, tooltip, mouseX, mouseY);
            cardTooltipShown = true;
        }

        // Vanilla tooltip uniquement si aucun tooltip custom affiché
        if (!domumTooltipShown && !cardTooltipShown)
            this.renderTooltip(graphics, mouseX, mouseY);
    }
    /**
     * Redessine les slots buffer du Redirector : si un slot contient un DomumPatternItem,
     * on rend l'item Domum cible PAR-DESSUS l'icône pattern.
     * Appelé après super.render() pour être au-dessus du rendu vanilla.
     * Client-side uniquement.
     */



}